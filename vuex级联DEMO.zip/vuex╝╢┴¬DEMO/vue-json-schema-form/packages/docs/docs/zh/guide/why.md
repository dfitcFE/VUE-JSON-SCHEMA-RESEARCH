# 为何开发

* 基于elementUi 和 Vue 可满足需求并且在维护的项目已经没有了...

* 项目需要就临时写了一个只支持普通object的版本

* 后续看了 [react-jsonschema-form](https://github.com/rjsf-team/react-jsonschema-form) 的实现决定逐步完善，然后就成这样了...
