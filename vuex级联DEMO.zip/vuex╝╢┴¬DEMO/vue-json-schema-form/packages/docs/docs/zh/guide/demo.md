# 使用场景

## 前端可视化数据配置
原本开发就是为了前端可视化数据配置系统，解决需要大量配置表单数据，以及如何和服务端的数据保持一致的场景。

* 地址：
[可视化页面（H5）活动编辑器](https://form.lljj.me/vue-editor.html)

## demo页面
* 说明

演示和测试目前支持的 JSON Schema 格式

* 地址：
[vjsf demo 演示页面](https://form.lljj.me)


## 其它场景
....
