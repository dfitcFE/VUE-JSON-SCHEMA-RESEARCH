import DemoBlock from './DemoBlock.vue'
export default ({ Vue }) => {
  Vue.component('DemoBlock', DemoBlock)
}
