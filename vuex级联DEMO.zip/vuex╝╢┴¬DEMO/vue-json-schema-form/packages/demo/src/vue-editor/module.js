/**
 * Created by Liu.Jun on 2019/11/28 13:25.
 */


export const Vue = window.Vue;
export const VueRouter = window.VueRouter;
export const ELEMENT = window.ELEMENT;
