/**
 * Created by Liu.Jun on 2020/4/30 17:13.
 */

import genImgItem from '../_commonConfig/ui/genImgItem';

export default {
    imgList: {
        items: genImgItem()
    }
};
