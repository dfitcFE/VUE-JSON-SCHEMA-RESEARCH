/**
 * Created by Liu.Jun on 2020/4/30 17:40.
 */

import genImgItem from '../_commonConfig/error/genImgItem';

export default {
    imgList: {
        items: genImgItem()
    }
};
