/**
 * Created by Liu.Jun on 2020/7/22 11:07 下午.
 */

export default {
    schema: {
        title: '测试专用页',
        type: 'object',
        description: '输入你的Schema，生成链接即可快速生成预览',
        properties: {
        }
    }
};
