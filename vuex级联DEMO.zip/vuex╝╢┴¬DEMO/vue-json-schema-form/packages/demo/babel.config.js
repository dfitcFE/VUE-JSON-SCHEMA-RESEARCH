module.exports = {
    plugins: [
        // '@babel/plugin-proposal-export-default-from'
    ],
    presets: [
        ['@vue/cli-plugin-babel/preset', {
            useBuiltIns: false
        }]
    ]
};
