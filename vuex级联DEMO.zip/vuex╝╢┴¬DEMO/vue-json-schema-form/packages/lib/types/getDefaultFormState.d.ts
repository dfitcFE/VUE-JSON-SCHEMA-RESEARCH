declare function getDefaultFormState(
    schema: object,
    formData: object,
    rootSchema: object,
    includeUndefinedValues?: boolean,
): any;

export default getDefaultFormState;
