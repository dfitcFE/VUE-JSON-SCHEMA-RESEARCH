declare namespace i18n {
    function getCurrentLocalize(): object;

    function useLocal(fn): object;
}

export default i18n;
