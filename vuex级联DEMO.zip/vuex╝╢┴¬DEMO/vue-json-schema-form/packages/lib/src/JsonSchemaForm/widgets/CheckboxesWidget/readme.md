### 文件说明
> 默认widget直接使用element的组件，这里附加一些不能直接满足场景而使用的组件

### 组件说明
单文件夹为单个组件，组件需要统一为v-model双向绑定值

#### CheckboxesWidget
说明：多选列表，接受value 和 enumOptions参数
> value - array，选中的值
> enumOptions - Array ，下拉选项

示例：
```js
console.log(1);
```
